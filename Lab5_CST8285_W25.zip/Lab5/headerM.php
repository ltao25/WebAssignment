<body>
    <header>
        <h1>ACME Corporation</h1>
        <div class="tagline">Movies you can watch!</div>
    </header>